/**
 * Cloudflare Worker — Proxy seguro para API do Notion
 * O token fica aqui no Worker, nunca exposto no HTML público
 */

const NOTION_TOKEN = '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';
const ALLOWED_ORIGIN = '*';

export default {
  async fetch(request) {
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
          'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE',
          'Access-Control-Allow-Headers': 'Content-Type',
        },
      });
    }

    const url = new URL(request.url);
    const notionPath = url.pathname.replace(/^\/notion/, '');
    const notionURL = `https://api.notion.com/v1${notionPath}`;

    const body = request.method !== 'GET' ? await request.text() : undefined;

    const notionResp = await fetch(notionURL, {
      method: request.method,
      headers: {
        'Authorization': `Bearer ${NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json',
      },
      body,
    });

    const data = await notionResp.text();

    return new Response(data, {
      status: notionResp.status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  },
};
